import React, { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { HeaderSection } from "./sections/HeaderSection";
import { FooterSection } from "./sections/FooterSection";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export const BookingForm = (): JSX.Element => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    nationality: "",
    destination: "",
    startDate: "",
    endDate: "",
    adults: "1",
    children: "0",
    budgetRange: "",
    accommodationType: "",
    transportPreference: "",
    dietaryRestrictions: "",
    specialRequests: "",
    hearAboutUs: "",
  });
  const { toast } = useToast();

  const steps = [
    { number: 1, label: "Personal" },
    { number: 2, label: "Trip" },
    { number: 3, label: "Budget" },
    { number: 4, label: "Questions" },
  ];

  const createBookingMutation = useMutation({
    mutationFn: async (bookingData: typeof formData) => {
      const response = await apiRequest("POST", "/api/bookings", {
        fullName: bookingData.fullName,
        email: bookingData.email,
        phone: bookingData.phone,
        nationality: bookingData.nationality,
        destination: bookingData.destination,
        startDate: bookingData.startDate,
        endDate: bookingData.endDate,
        adults: parseInt(bookingData.adults),
        children: parseInt(bookingData.children),
        budgetRange: bookingData.budgetRange,
        accommodationType: bookingData.accommodationType,
        transportPreference: bookingData.transportPreference,
        dietaryRestrictions: bookingData.dietaryRestrictions || null,
        specialRequests: bookingData.specialRequests || null,
        hearAboutUs: bookingData.hearAboutUs || null,
      });
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking submitted successfully!",
        description: "Thank you for your booking request. We will contact you shortly.",
      });
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        nationality: "",
        destination: "",
        startDate: "",
        endDate: "",
        adults: "1",
        children: "0",
        budgetRange: "",
        accommodationType: "",
        transportPreference: "",
        dietaryRestrictions: "",
        specialRequests: "",
        hearAboutUs: "",
      });
      setCurrentStep(1);
    },
    onError: () => {
      toast({
        title: "Error submitting booking",
        description: "Please check your information and try again.",
        variant: "destructive",
      });
    },
  });

  const handleContinue = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleSubmit = () => {
    createBookingMutation.mutate(formData);
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="bg-[#f8f8f8] w-full min-h-screen relative flex flex-col">
      <HeaderSection />

      <div className="flex-1 py-16 px-[68px]">
        <div className="w-full max-w-[896px] mx-auto">
          <div className="flex items-center justify-center gap-2 mb-8">
            {steps.map((step, index) => (
              <React.Fragment key={step.number}>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      step.number === currentStep
                        ? "bg-[#101828] text-white"
                        : step.number < currentStep
                        ? "bg-[#4a5565] text-white"
                        : "bg-[#d1d5dc] text-[#4a5565]"
                    }`}
                  >
                    <span className="[font-family:'Inter',sans-serif] font-normal text-base tracking-[-0.31px]">
                      {step.number}
                    </span>
                  </div>
                  <span className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px]">
                    {step.label}
                  </span>
                </div>
                {index < steps.length - 1 && (
                  <div className="w-8 h-0.5 bg-[#d1d5dc]" />
                )}
              </React.Fragment>
            ))}
          </div>

          <div className="bg-white rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)] p-8">
            {currentStep === 1 && (
              <>
                <h2 className="[font-family:'Inter',sans-serif] font-normal text-[#101828] text-base tracking-[-0.31px] leading-6 mb-6">
                  Personal Information
                </h2>

                <div className="flex flex-col gap-6">
                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="fullName"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      Full Name
                    </Label>
                    <Input
                      id="fullName"
                      type="text"
                      placeholder="John Doe"
                      value={formData.fullName}
                      onChange={(e) =>
                        setFormData({ ...formData, fullName: e.target.value })
                      }
                      className="bg-gray-50 rounded-lg h-9 px-3 [font-family:'Inter',sans-serif] font-normal text-sm tracking-[-0.15px]"
                    />
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="email"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      Email Address
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="john.doe@example.com"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      className="bg-gray-50 rounded-lg h-9 px-3 [font-family:'Inter',sans-serif] font-normal text-sm tracking-[-0.15px]"
                    />
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="phone"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      Phone Number
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="301-XXX-XXX"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className="bg-gray-50 rounded-lg h-9 px-3 [font-family:'Inter',sans-serif] font-normal text-sm tracking-[-0.15px]"
                    />
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="nationality"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      Nationality
                    </Label>
                    <Select
                      value={formData.nationality}
                      onValueChange={(value) =>
                        setFormData({ ...formData, nationality: value })
                      }
                    >
                      <SelectTrigger className="bg-gray-50 rounded-lg h-9 px-3">
                        <SelectValue placeholder="Select nationality" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="us">United States</SelectItem>
                        <SelectItem value="uk">United Kingdom</SelectItem>
                        <SelectItem value="ca">Canada</SelectItem>
                        <SelectItem value="au">Australia</SelectItem>
                        <SelectItem value="de">Germany</SelectItem>
                        <SelectItem value="fr">France</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    onClick={handleContinue}
                    className="w-full bg-[#101828] hover:bg-[#000000] text-white rounded-lg h-12 mt-4"
                  >
                    <span className="[font-family:'Inter',sans-serif] font-medium text-sm tracking-[-0.15px]">
                      Continue
                    </span>
                  </Button>
                </div>
              </>
            )}

            {currentStep === 2 && (
              <>
                <div className="flex items-center gap-4 mb-6">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleBack}
                    className="rounded-lg w-9 h-9 p-2"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                  <h2 className="[font-family:'Inter',sans-serif] font-medium text-[#101828] text-xl tracking-[-0.45px] leading-[30px]">
                    Trip Information
                  </h2>
                </div>

                <div className="flex flex-col gap-6">
                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="destination"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      Destination
                    </Label>
                    <Select
                      value={formData.destination}
                      onValueChange={(value) =>
                        setFormData({ ...formData, destination: value })
                      }
                    >
                      <SelectTrigger className="bg-gray-50 rounded-lg h-9 px-3">
                        <SelectValue placeholder="Select destination" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="serengeti">Serengeti National Park</SelectItem>
                        <SelectItem value="kilimanjaro">Mount Kilimanjaro</SelectItem>
                        <SelectItem value="ngorongoro">Ngorongoro Crater</SelectItem>
                        <SelectItem value="tarangire">Tarangire National Park</SelectItem>
                        <SelectItem value="zanzibar">Zanzibar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-2">
                      <Label
                        htmlFor="startDate"
                        className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                      >
                        Start Date
                      </Label>
                      <Input
                        id="startDate"
                        type="date"
                        value={formData.startDate}
                        onChange={(e) =>
                          setFormData({ ...formData, startDate: e.target.value })
                        }
                        className="bg-gray-50 rounded-lg h-9 px-3 [font-family:'Inter',sans-serif] font-normal text-sm tracking-[-0.15px]"
                      />
                    </div>

                    <div className="flex flex-col gap-2">
                      <Label
                        htmlFor="endDate"
                        className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                      >
                        End Date
                      </Label>
                      <Input
                        id="endDate"
                        type="date"
                        value={formData.endDate}
                        onChange={(e) =>
                          setFormData({ ...formData, endDate: e.target.value })
                        }
                        className="bg-gray-50 rounded-lg h-9 px-3 [font-family:'Inter',sans-serif] font-normal text-sm tracking-[-0.15px]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-2">
                      <Label
                        htmlFor="adults"
                        className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                      >
                        Number of Adults
                      </Label>
                      <Input
                        id="adults"
                        type="number"
                        min="1"
                        value={formData.adults}
                        onChange={(e) =>
                          setFormData({ ...formData, adults: e.target.value })
                        }
                        className="bg-gray-50 rounded-lg h-9 px-3 [font-family:'Inter',sans-serif] font-normal text-sm tracking-[-0.15px]"
                      />
                    </div>

                    <div className="flex flex-col gap-2">
                      <Label
                        htmlFor="children"
                        className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                      >
                        Number of Children
                      </Label>
                      <Input
                        id="children"
                        type="number"
                        min="0"
                        value={formData.children}
                        onChange={(e) =>
                          setFormData({ ...formData, children: e.target.value })
                        }
                        className="bg-gray-50 rounded-lg h-9 px-3 [font-family:'Inter',sans-serif] font-normal text-sm tracking-[-0.15px]"
                      />
                    </div>
                  </div>

                  <Button
                    onClick={handleContinue}
                    className="w-full bg-[#101828] hover:bg-[#000000] text-white rounded-lg h-12 mt-4"
                  >
                    <span className="[font-family:'Inter',sans-serif] font-medium text-sm tracking-[-0.15px]">
                      Continue
                    </span>
                  </Button>
                </div>
              </>
            )}

            {currentStep === 3 && (
              <>
                <div className="flex items-center gap-4 mb-6">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleBack}
                    className="rounded-lg w-9 h-9 p-2"
                    data-testid="button-back-budget"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                  <h2 className="[font-family:'Inter',sans-serif] font-medium text-[#101828] text-xl tracking-[-0.45px] leading-[30px]">
                    Budget & Preferences
                  </h2>
                </div>

                <div className="flex flex-col gap-6">
                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="budgetRange"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      Budget Range (Per Person)
                    </Label>
                    <Select
                      value={formData.budgetRange}
                      onValueChange={(value) =>
                        setFormData({ ...formData, budgetRange: value })
                      }
                    >
                      <SelectTrigger className="bg-gray-50 rounded-lg h-9 px-3" data-testid="select-budget-range">
                        <SelectValue placeholder="Select budget range" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="budget">Budget ($500 - $1,000)</SelectItem>
                        <SelectItem value="mid-range">Mid-Range ($1,000 - $2,500)</SelectItem>
                        <SelectItem value="luxury">Luxury ($2,500 - $5,000)</SelectItem>
                        <SelectItem value="ultra-luxury">Ultra Luxury ($5,000+)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="accommodationType"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      Accommodation Type
                    </Label>
                    <Select
                      value={formData.accommodationType}
                      onValueChange={(value) =>
                        setFormData({ ...formData, accommodationType: value })
                      }
                    >
                      <SelectTrigger className="bg-gray-50 rounded-lg h-9 px-3" data-testid="select-accommodation">
                        <SelectValue placeholder="Select accommodation preference" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="camping">Camping</SelectItem>
                        <SelectItem value="basic-lodge">Basic Lodge</SelectItem>
                        <SelectItem value="standard-hotel">Standard Hotel</SelectItem>
                        <SelectItem value="luxury-lodge">Luxury Lodge</SelectItem>
                        <SelectItem value="luxury-tented">Luxury Tented Camp</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="transportPreference"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      Transport Preference
                    </Label>
                    <Select
                      value={formData.transportPreference}
                      onValueChange={(value) =>
                        setFormData({ ...formData, transportPreference: value })
                      }
                    >
                      <SelectTrigger className="bg-gray-50 rounded-lg h-9 px-3" data-testid="select-transport">
                        <SelectValue placeholder="Select transport preference" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="shared">Shared Vehicle</SelectItem>
                        <SelectItem value="private">Private Vehicle</SelectItem>
                        <SelectItem value="private-luxury">Private Luxury Vehicle</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    onClick={handleContinue}
                    className="w-full bg-[#101828] hover:bg-[#000000] text-white rounded-lg h-12 mt-4"
                    data-testid="button-continue-budget"
                  >
                    <span className="[font-family:'Inter',sans-serif] font-medium text-sm tracking-[-0.15px]">
                      Continue
                    </span>
                  </Button>
                </div>
              </>
            )}

            {currentStep === 4 && (
              <>
                <div className="flex items-center gap-4 mb-6">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleBack}
                    className="rounded-lg w-9 h-9 p-2"
                    data-testid="button-back-questions"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                  <h2 className="[font-family:'Inter',sans-serif] font-medium text-[#101828] text-xl tracking-[-0.45px] leading-[30px]">
                    Additional Information
                  </h2>
                </div>

                <div className="flex flex-col gap-6">
                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="dietaryRestrictions"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      Dietary Restrictions or Allergies
                    </Label>
                    <Textarea
                      id="dietaryRestrictions"
                      placeholder="Please let us know about any dietary restrictions, allergies, or food preferences..."
                      value={formData.dietaryRestrictions}
                      onChange={(e) =>
                        setFormData({ ...formData, dietaryRestrictions: e.target.value })
                      }
                      className="bg-gray-50 rounded-lg px-3 py-2 min-h-[100px] [font-family:'Inter',sans-serif] font-normal text-sm tracking-[-0.15px] resize-none"
                      data-testid="textarea-dietary"
                    />
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="specialRequests"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      Special Requests or Questions
                    </Label>
                    <Textarea
                      id="specialRequests"
                      placeholder="Any special requests, questions, or additional information you'd like to share..."
                      value={formData.specialRequests}
                      onChange={(e) =>
                        setFormData({ ...formData, specialRequests: e.target.value })
                      }
                      className="bg-gray-50 rounded-lg px-3 py-2 min-h-[100px] [font-family:'Inter',sans-serif] font-normal text-sm tracking-[-0.15px] resize-none"
                      data-testid="textarea-special-requests"
                    />
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label
                      htmlFor="hearAboutUs"
                      className="[font-family:'Inter',sans-serif] font-medium text-[#4a5565] text-xs tracking-[0.3px] uppercase leading-4"
                    >
                      How Did You Hear About Us?
                    </Label>
                    <Select
                      value={formData.hearAboutUs}
                      onValueChange={(value) =>
                        setFormData({ ...formData, hearAboutUs: value })
                      }
                    >
                      <SelectTrigger className="bg-gray-50 rounded-lg h-9 px-3" data-testid="select-hear-about">
                        <SelectValue placeholder="Select an option" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="google">Google Search</SelectItem>
                        <SelectItem value="social-media">Social Media</SelectItem>
                        <SelectItem value="friend">Friend or Family</SelectItem>
                        <SelectItem value="travel-agent">Travel Agent</SelectItem>
                        <SelectItem value="previous-customer">Previous Customer</SelectItem>
                        <SelectItem value="advertisement">Advertisement</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    onClick={handleSubmit}
                    disabled={createBookingMutation.isPending}
                    className="w-full bg-[#ff7722] hover:bg-[#e66612] text-white rounded-lg h-12 mt-4 disabled:opacity-50 disabled:cursor-not-allowed"
                    data-testid="button-submit-booking"
                  >
                    <span className="[font-family:'Inter',sans-serif] font-medium text-sm tracking-[-0.15px]">
                      {createBookingMutation.isPending ? "Submitting..." : "Submit Booking Request"}
                    </span>
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="bg-[#f4d4a8] py-12 px-[68px]">
        <div className="w-full max-w-[1280px] mx-auto">
          <div className="grid grid-cols-3 gap-12 mb-8">
            <div className="flex flex-col gap-4">
              <h3 className="[font-family:'Inter',sans-serif] font-normal text-[#101828] text-base tracking-[-0.31px]">
                Grant Expedition
              </h3>
              <p className="[font-family:'Inter',sans-serif] italic font-normal text-[#364153] text-base tracking-[-0.31px]">
                [Placeholder Text]
              </p>
              <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                Your trusted safari and adventure tour operator in Tanzania. Creating unforgettable experiences since 2010.
              </p>
            </div>

            <div className="flex flex-col gap-4">
              <h3 className="[font-family:'Inter',sans-serif] font-medium text-[#101828] text-lg tracking-[-0.44px]">
                Support
              </h3>
              <div className="flex flex-col gap-2">
                <a href="#" className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">FAQ</a>
                <a href="#" className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Help Center</a>
                <a href="#" className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Terms & Conditions</a>
                <a href="#" className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Privacy Policy</a>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              <h3 className="[font-family:'Inter',sans-serif] font-normal text-[#101828] text-base tracking-[-0.31px]">
                Contact
              </h3>
              <div className="flex flex-col gap-2">
                <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Email:</p>
                <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Phone:</p>
                <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Location</p>
              </div>
            </div>
          </div>

          <div className="border-t border-[#d1d5dc] pt-4 flex gap-6">
            <a href="#" className="flex items-center gap-2">
              <span className="[font-family:'Inter',sans-serif] font-normal text-[#101828] text-base tracking-[-0.31px]">Facebook</span>
            </a>
            <a href="#" className="flex items-center gap-2">
              <span className="[font-family:'Inter',sans-serif] font-normal text-[#101828] text-base tracking-[-0.31px]">Twitter</span>
            </a>
            <a href="#" className="flex items-center gap-2">
              <span className="[font-family:'Inter',sans-serif] font-normal text-[#101828] text-base tracking-[-0.31px]">Instagram</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
