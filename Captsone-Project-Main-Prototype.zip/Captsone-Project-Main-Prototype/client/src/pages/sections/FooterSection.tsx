import { FacebookIcon, InstagramIcon, TwitterIcon } from "lucide-react";
import React from "react";

const footerColumns = [
  {
    title: "Grant Expedition",
    content: [
      {
        text: "Your trusted safari and adventure tour operator in Tanzania.",
        isDescription: true,
      },
      {
        text: "Creating unforgettable experiences since 2010.",
        isDescription: true,
      },
    ],
  },
  {
    title: "Support",
    content: [
      { text: "FAQ", isDescription: false },
      { text: "Help Center", isDescription: false },
      { text: "Terms & Conditions", isDescription: false },
      { text: "Privacy Policy", isDescription: false },
    ],
  },
  {
    title: "Contact",
    content: [
      { text: "Email:", isDescription: false },
      { text: "Phone:", isDescription: false },
      { text: "Location", isDescription: false },
    ],
  },
];

const socialLinks = [
  { icon: FacebookIcon, label: "Facebook", url: "https://www.facebook.com/people/Grant-expedition-ltd/100063871123184/" },
  { icon: TwitterIcon, label: "Twitter", url: null },
  { icon: InstagramIcon, label: "Instagram", url: "https://www.instagram.com/grant_expedition_ltd/?hl=en" },
];

export const FooterSection = (): JSX.Element => {
  return (
    <footer className="flex w-full relative mt-12 flex-col items-start gap-6 pt-8 pb-0 px-6 bg-[#ffd6a8]">
      <div className="grid grid-cols-3 gap-8 w-full">
        {footerColumns.map((column, index) => (
          <div key={index} className="flex flex-col items-start gap-3">
            <h3 className="[font-family:'Merriweather',Helvetica] font-normal text-black text-base tracking-[0] leading-6">
              {column.title}
            </h3>
            <div className="flex flex-col items-start gap-2">
              {column.content.map((item, itemIndex) => (
                <p
                  key={itemIndex}
                  className={`[font-family:'Merriweather',Helvetica] font-normal text-black text-sm tracking-[0] leading-5 ${
                    item.isDescription ? "italic opacity-60" : ""
                  }`}
                >
                  {item.text}
                </p>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-4 w-full border-t border-solid border-[#ffb869] pt-4">
        {socialLinks.map((social, index) => {
          const IconComponent = social.icon;
          const content = (
            <>
              <IconComponent className="w-5 h-5" />
              <span className="[font-family:'Merriweather',Helvetica] font-normal text-black text-base tracking-[0] leading-6">
                {social.label}
              </span>
            </>
          );
          
          return social.url ? (
            <a
              key={index}
              href={social.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 hover:opacity-70 transition-opacity cursor-pointer"
              data-testid={`link-${social.label.toLowerCase()}`}
            >
              {content}
            </a>
          ) : (
            <div key={index} className="flex items-center gap-2">
              {content}
            </div>
          );
        })}
      </div>
    </footer>
  );
};
