import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const reviewsData = [
  {
    name: "shabanabashir",
    date: "2022-10-12",
    text: "We had amazing experience with grant expedition from hiking to kilimanjaro summit through machame route to Safari and zanzibar. Everything was top cla...",
  },
  {
    name: "Alicia is key",
    date: "2022-09-27",
    text: "Thankyou so much to the whole team! I had the experience of a lifetime! I set out to climb Kilimanjaro, and because of Grant Expedition, I achieved my...",
  },
  {
    name: "Jeffrey Gleijm",
    date: "2022-07-20",
    text: "What a nice experience! We made a day trip from Zanzibar and Samuel helped us a lot with the tickets. grand expedition picked us up once we arrived at...",
  },
  {
    name: "George",
    date: "Jan 2022",
    text: "Grant Expedition and Samuel are the most professional tour operator for safari and other tours! We had the chance to organize everything in order to h...",
  },
];

export const ContentWrapperSection = (): JSX.Element => {
  return (
    <section className="flex flex-col w-full max-w-52 items-center gap-4 px-4 py-12">
      <div className="flex w-full items-center justify-center gap-2">
        <img
          className="w-6 h-6"
          alt="Google icon"
          src="/figmaAssets/icon-7.svg"
        />
        <span className="[font-family:'Merriweather',Helvetica] font-normal text-black text-sm text-center tracking-[0] leading-5">
          Google
        </span>
      </div>

      {reviewsData.map((review, index) => (
        <Card
          key={index}
          className="w-full bg-white rounded border border-solid border-[#ffb869]"
        >
          <CardContent className="p-[17px] flex flex-col gap-4">
            <img
              className="w-full h-3"
              alt="5 star rating"
              src="/figmaAssets/container.svg"
            />

            <div className="flex flex-col gap-2">
              <p className="[font-family:'Merriweather',Helvetica] font-normal text-neutral-950 text-xs tracking-[0] leading-4">
                {review.name}
              </p>

              <p className="[font-family:'Merriweather',Helvetica] font-normal text-[#697282] text-xs tracking-[0] leading-4">
                {review.date}
              </p>
            </div>

            <p className="[font-family:'Merriweather',Helvetica] font-normal text-black text-xs tracking-[0] leading-[19.5px]">
              {review.text}
            </p>

            <button className="text-left [font-family:'Merriweather',Helvetica] font-normal text-[#f54900] text-xs tracking-[0] leading-4">
              Read more
            </button>
          </CardContent>
        </Card>
      ))}
    </section>
  );
};
