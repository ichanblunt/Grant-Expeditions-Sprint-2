import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const statsData = [
  {
    value: "2012",
    label: "Established",
    gridClass: "row-[1_/_2] col-[1_/_2]",
  },
  {
    value: "1000+",
    label: "Guests Hosted",
    gridClass: "row-[1_/_2] col-[2_/_3]",
  },
  {
    value: "4x4",
    labels: ["Fleet", "Reliable Vehicles"],
    gridClass: "row-[2_/_3] col-[1_/_2]",
  },
  {
    value: "24/7",
    labels: ["Local", "Support"],
    gridClass: "row-[2_/_3] col-[2_/_3]",
  },
];

export const ActivitiesSection = (): JSX.Element => {
  return (
    <section className="w-full flex border-b [border-bottom-style:solid] border-[#0000001a]">
      <div className="w-[474.33px] h-80 bg-[url(/figmaAssets/imagewithfallback-13.svg)] bg-cover bg-[50%_50%]" />

      <div className="flex w-[474.33px] h-[358px] flex-col items-start justify-center gap-3 pl-6 pr-0 py-0 border-r [border-right-style:solid] border-[#0000001a]">
        <div className="w-[425.33px] h-[30px]">
          <h2 className="[font-family:'Merriweather',Helvetica] font-normal text-neutral-950 text-xl tracking-[0] leading-[30px] whitespace-nowrap">
            About
          </h2>
        </div>

        <div className="w-[425.33px] h-[216px] opacity-60">
          <p className="w-[423px] [font-family:'Merriweather',Helvetica] font-normal text-black text-base tracking-[0] leading-6">
            Headquartered in Arusha, Tanzania, Grant Expedition specializes in
            creating unforgettable safari experiences across Tanzania&apos;s
            most stunning landscapes. We deliver personalized itineraries
            blending luxury, comfort, and authenticity.
          </p>

          <p className="mt-6 w-[415px] [font-family:'Merriweather',Helvetica] font-normal text-black text-base tracking-[0] leading-6">
            Whether you are seeking thrilling wildlife encounters, breathtaking
            natural wonders, or immersive cultural experiences, Grant Expedition
            is your trusted partner in discovering the best of Tanzania.
          </p>
        </div>
      </div>

      <div className="grid mt-6 w-[426.33px] h-[310px] ml-6 grid-cols-[205.16px_minmax(0,1fr)] grid-rows-[140.00px_minmax(0,1fr)] gap-4">
        {statsData.map((stat, index) => (
          <Card
            key={index}
            className={`${stat.gridClass} w-full h-full bg-gray-100 rounded-2xl border border-solid`}
          >
            <CardContent className="flex flex-col items-start justify-center gap-2 pl-6 pr-0 py-0 h-full">
              <div className="w-[155.16px] h-10">
                <div className="[font-family:'Merriweather',Helvetica] font-bold text-[#008235] text-4xl text-center tracking-[0] leading-10 whitespace-nowrap">
                  {stat.value}
                </div>
              </div>

              {stat.labels ? (
                <>
                  <div className="w-[155.16px] h-7">
                    <div className="[font-family:'Merriweather',Helvetica] font-normal text-black text-lg text-center tracking-[0] leading-7 whitespace-nowrap">
                      {stat.labels[0]}
                    </div>
                  </div>
                  <div className="w-[155.16px] h-7">
                    <div className="[font-family:'Merriweather',Helvetica] font-normal text-black text-lg text-center tracking-[0] leading-7 whitespace-nowrap">
                      {stat.labels[1]}
                    </div>
                  </div>
                </>
              ) : (
                <div className="w-[155.16px] h-7">
                  <div className="[font-family:'Merriweather',Helvetica] font-normal text-black text-lg text-center tracking-[0] leading-7 whitespace-nowrap">
                    {stat.label}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};
