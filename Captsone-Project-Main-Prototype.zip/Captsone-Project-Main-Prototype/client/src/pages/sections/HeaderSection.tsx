import { ChevronDownIcon } from "lucide-react";
import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import logoImage from "@assets/GE - Logo_1762319416100.jpg";

const navigationItems = [
  { label: "Home", hasDropdown: false },
  { label: "About Us", hasDropdown: false },
  { label: "Trekking", hasDropdown: true },
  { label: "Safari Tours", hasDropdown: true },
  { label: "Destinations", hasDropdown: true },
  { label: "Contact Us", hasDropdown: false },
];

export const HeaderSection = (): JSX.Element => {
  return (
    <header className="flex w-full relative flex-col items-start bg-white border-b border-[#0000001a]">
      <div className="flex h-[98px] items-center justify-between px-24 py-0 w-full">
        <Link href="/">
          <img src={logoImage} alt="Grant Expedition" className="h-[66px] w-auto cursor-pointer" />
        </Link>

        <nav className="flex items-center gap-6">
          {navigationItems.map((item, index) => {
            if (item.label === "Home") {
              return (
                <Link key={index} href="/">
                  <div className="flex items-center gap-1 cursor-pointer">
                    <div className="[font-family:'Merriweather',Helvetica] font-normal text-black text-lg tracking-[0] leading-7 whitespace-nowrap">
                      {item.label}
                    </div>
                    {item.hasDropdown && <ChevronDownIcon className="w-4 h-4" />}
                  </div>
                </Link>
              );
            } else if (item.label === "Contact Us") {
              return (
                <Link key={index} href="/contact">
                  <div className="flex items-center gap-1 cursor-pointer">
                    <div className="[font-family:'Merriweather',Helvetica] font-normal text-black text-lg tracking-[0] leading-7 whitespace-nowrap">
                      {item.label}
                    </div>
                    {item.hasDropdown && <ChevronDownIcon className="w-4 h-4" />}
                  </div>
                </Link>
              );
            } else {
              return (
                <div key={index} className="flex items-center gap-1 cursor-pointer">
                  <div className="[font-family:'Merriweather',Helvetica] font-normal text-black text-lg tracking-[0] leading-7 whitespace-nowrap">
                    {item.label}
                  </div>
                  {item.hasDropdown && <ChevronDownIcon className="w-4 h-4" />}
                </div>
              );
            }
          })}
        </nav>

        <Button className="h-auto bg-[#ff6800] hover:bg-[#ff6800]/90 rounded-full px-6 py-2 border border-solid">
          <span className="[font-family:'Merriweather',Helvetica] font-normal text-white text-lg tracking-[0] leading-7 whitespace-nowrap">
            Plan my own Safari
          </span>
        </Button>
      </div>
    </header>
  );
};
