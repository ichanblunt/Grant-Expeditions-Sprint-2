import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Facebook, Twitter, Instagram, MapPin } from "lucide-react";
import { HeaderSection } from "./sections/HeaderSection";

export const ContactUs = (): JSX.Element => {
  return (
    <div className="bg-[#f8f8f8] w-full min-h-screen relative flex flex-col">
      <HeaderSection />

      <div className="bg-[#00a63e] border-b border-[#e8c5a0] py-16 px-[68px]">
        <div className="w-full max-w-[1280px] mx-auto">
          <h1 className="[font-family:'Inter',sans-serif] font-bold text-[48px] text-black text-center tracking-[0.35px] leading-[48px]">
            Contact Grant Expedition
          </h1>
        </div>
      </div>

      <div className="flex-1 py-12 px-[68px]">
        <div className="w-full max-w-[1280px] mx-auto flex gap-8">
          <div className="flex flex-col gap-6 w-[395px]">
            <div className="bg-white border border-[#e8c5a0] rounded-[10px] p-6">
              <div className="flex flex-col gap-3">
                <a
                  href="https://www.facebook.com/people/Grant-expedition-ltd/100063871123184/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 hover:opacity-70 transition-opacity cursor-pointer"
                  data-testid="link-facebook"
                >
                  <Facebook className="w-5 h-5" />
                  <span className="[font-family:'Inter',sans-serif] font-normal text-[#1e2939] text-base tracking-[-0.31px]">
                    Facebook
                  </span>
                </a>
                <div className="flex items-center gap-3">
                  <Twitter className="w-5 h-5" />
                  <span className="[font-family:'Inter',sans-serif] font-normal text-[#1e2939] text-base tracking-[-0.31px]">
                    Twitter
                  </span>
                </div>
                <a
                  href="https://www.instagram.com/grant_expedition_ltd/?hl=en"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 hover:opacity-70 transition-opacity cursor-pointer"
                  data-testid="link-instagram"
                >
                  <Instagram className="w-5 h-5" />
                  <span className="[font-family:'Inter',sans-serif] font-normal text-[#1e2939] text-base tracking-[-0.31px]">
                    Instagram
                  </span>
                </a>
              </div>
            </div>

            <div className="bg-white border border-[#e8c5a0] rounded-[10px] p-6">
              <div className="flex flex-col gap-6">
                <div className="flex flex-col gap-3">
                  <h3 className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-base tracking-[-0.31px]">
                    Head Office
                  </h3>
                  <div className="flex flex-col gap-2">
                    <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">
                      <span className="font-medium">Address:</span> Usa River, Arusha, Tanzania
                    </p>
                    <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">
                      <span className="font-medium">Phone:</span> +255 766 437 358
                    </p>
                    <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">
                      <span className="font-medium">Email:</span> info@grantexepedition
                    </p>
                    <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">
                      <span className="font-medium">Office Hours:</span> Mon-Sat: 8:00 AM-6:00 PM
                    </p>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <h3 className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-lg tracking-[-0.44px]">
                    Emergency Contact
                  </h3>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-base tracking-[-0.31px] leading-6">
                    For urgent safari assistance or wildlife emergencies; Call the number above. Available 24/7
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex-1 flex flex-col gap-6">
            <div className="bg-white rounded-[14px] h-[256px] relative overflow-hidden flex items-center justify-center">
              <div className="bg-[#e7000b] rounded-full w-12 h-12 flex items-center justify-center shadow-lg">
                <MapPin className="w-6 h-6 text-white" />
              </div>
            </div>

            <div className="bg-white border border-[#e8c5a0] rounded-[14px] p-8">
              <h2 className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-[30px] text-center tracking-[0.4px] leading-9 mb-12">
                Travel Tips Before You Call
              </h2>

              <div className="flex flex-col gap-3">
                <div className="flex gap-3">
                  <span className="[font-family:'Inter',sans-serif] font-bold text-[#e8c5a0] text-base">•</span>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-sm tracking-[-0.15px] leading-5">
                    Check seasonal wildlife migrations to choose the best safari dates.
                  </p>
                </div>
                <div className="flex gap-3">
                  <span className="[font-family:'Inter',sans-serif] font-bold text-[#e8c5a0] text-base">•</span>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-sm tracking-[-0.15px] leading-5">
                    Ensure your passport and visas are valid for Tanzania.
                  </p>
                </div>
                <div className="flex gap-3">
                  <span className="[font-family:'Inter',sans-serif] font-bold text-[#e8c5a0] text-base">•</span>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-sm tracking-[-0.15px] leading-5">
                    Bring appropriate safari clothing, including hats, neutral colors, and good walking shoes.
                  </p>
                </div>
                <div className="flex gap-3">
                  <span className="[font-family:'Inter',sans-serif] font-bold text-[#e8c5a0] text-base">•</span>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-sm tracking-[-0.15px] leading-5">
                    Vaccinations may be required; consult your healthcare provider before traveling.
                  </p>
                </div>
                <div className="flex gap-3">
                  <span className="[font-family:'Inter',sans-serif] font-bold text-[#e8c5a0] text-base">•</span>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-sm tracking-[-0.15px] leading-5">
                    Plan for early morning game drives — wake-up times can be as early as 5:30 AM.
                  </p>
                </div>
                <div className="flex gap-3">
                  <span className="[font-family:'Inter',sans-serif] font-bold text-[#e8c5a0] text-base">•</span>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-sm tracking-[-0.15px] leading-5">
                    Confirm your travel insurance covers adventure and safari activities.
                  </p>
                </div>
                <div className="flex gap-3">
                  <span className="[font-family:'Inter',sans-serif] font-bold text-[#e8c5a0] text-base">•</span>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-sm tracking-[-0.15px] leading-5">
                    Respect local cultures, traditions, and environmental guidelines.
                  </p>
                </div>
                <div className="flex gap-3">
                  <span className="[font-family:'Inter',sans-serif] font-bold text-[#e8c5a0] text-base">•</span>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-sm tracking-[-0.15px] leading-5">
                    Stay hydrated and carry sunscreen and insect repellent.
                  </p>
                </div>
                <div className="flex gap-3">
                  <span className="[font-family:'Inter',sans-serif] font-bold text-[#e8c5a0] text-base">•</span>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#1e2939] text-sm tracking-[-0.15px] leading-5">
                    These tips help you have a safe, smooth, and memorable safari experience with Grant Expedition.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-[#f4d4a8] py-12 px-[68px]">
        <div className="w-full max-w-[1280px] mx-auto">
          <div className="grid grid-cols-3 gap-12 mb-8">
            <div className="flex flex-col gap-4">
              <h3 className="[font-family:'Inter',sans-serif] font-normal text-[#101828] text-base tracking-[-0.31px]">
                Grant Expedition
              </h3>
              <p className="[font-family:'Inter',sans-serif] italic font-normal text-[#364153] text-base tracking-[-0.31px]">
                [Placeholder Text]
              </p>
              <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                Your trusted safari and adventure tour operator in Tanzania. Creating unforgettable experiences since 2010.
              </p>
            </div>

            <div className="flex flex-col gap-4">
              <h3 className="[font-family:'Inter',sans-serif] font-medium text-[#101828] text-lg tracking-[-0.44px]">
                Support
              </h3>
              <div className="flex flex-col gap-2">
                <a href="#" className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">FAQ</a>
                <a href="#" className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Help Center</a>
                <a href="#" className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Terms & Conditions</a>
                <a href="#" className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Privacy Policy</a>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              <h3 className="[font-family:'Inter',sans-serif] font-normal text-[#101828] text-base tracking-[-0.31px]">
                Contact
              </h3>
              <div className="flex flex-col gap-2">
                <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Email:</p>
                <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Phone:</p>
                <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px]">Location</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Facebook className="w-5 h-5" />
              <span className="[font-family:'Inter',sans-serif] font-normal text-[#1e2939] text-sm tracking-[-0.15px]">Facebook</span>
            </div>
            <div className="flex items-center gap-2">
              <Twitter className="w-5 h-5" />
              <span className="[font-family:'Inter',sans-serif] font-normal text-[#1e2939] text-sm tracking-[-0.15px]">Twitter</span>
            </div>
            <div className="flex items-center gap-2">
              <Instagram className="w-5 h-5" />
              <span className="[font-family:'Inter',sans-serif] font-normal text-[#1e2939] text-sm tracking-[-0.15px]">Instagram</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
