import React from "react";
import { Link } from "wouter";
import { HeaderSection } from "./sections/HeaderSection";
import { FooterSection } from "./sections/FooterSection";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const TanzaniaSafariDetail = (): JSX.Element => {
  return (
    <div className="bg-white w-full relative flex flex-col">
      <HeaderSection />

      <div className="w-full relative bg-gradient-to-b from-gray-200 to-gray-400 py-32 px-[71.5px]">
        <div className="w-full max-w-[1280px] mx-auto flex flex-col gap-2">
          <h1 className="[font-family:'Inter',sans-serif] font-bold text-black text-5xl tracking-[0.35px] leading-[48px]">
            6-Day Luxury Highlights of Tanzania Safari
          </h1>
          <p className="[font-family:'Inter',sans-serif] font-normal text-white/90 text-base tracking-[-0.31px] leading-6">
            Experience the wonders of the Serengeti and Ngorongoro Crater
          </p>
        </div>
      </div>

      <div className="w-full relative py-12 px-[95.5px]">
        <div className="w-full max-w-[1280px] mx-auto flex gap-8">
          <div className="flex-1 flex flex-col gap-8">
            <div className="flex flex-col gap-4">
              <h2 className="[font-family:'Inter',sans-serif] font-medium text-black text-xl tracking-[-0.45px] leading-[30px] border-b-2 border-[#ffb86a] pb-2">
                Overview
              </h2>
              <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-base tracking-[-0.31px] leading-6">
                On this 6-day luxury safari, you will experience the best Tanzania has to offer, including two nights in the Serengeti. Accommodations are of a very high standard and will provide you with plenty of 'aahhhh' moments after your day's exploring. You will experience breathtaking wildlife including opportunities to see lions in trees, elephants traveling through the bush, and a huge variety of animals inside a collapsed volcano. Wow moments will be countless and with a bit of luck, you will see the Big 5!
              </p>
            </div>

            <div className="flex flex-col gap-4">
              <h2 className="[font-family:'Inter',sans-serif] font-medium text-black text-base tracking-[-0.31px] leading-6 border-b-2 border-[#ffb86a] pb-2">
                Day by Day Itinerary
              </h2>

              <Card className="border border-[#ffd6a7] rounded-[10px]">
                <CardContent className="p-4 flex flex-col gap-4">
                  <div className="bg-[#ffedd4] px-2 py-1 inline-block">
                    <h3 className="[font-family:'Inter',sans-serif] font-normal text-base text-black tracking-[-0.31px]">
                      Day 1: Arrival & Orientation
                    </h3>
                  </div>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    Welcome to Tanzania! You will be picked up from the airport by a Grant Expedition representative and driven to your accommodation in Arusha. Depending on your arrival time, you will hopefully have time to relax and prepare for the adventure of a lifetime!
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#364153] text-sm tracking-[-0.15px]">Accommodation</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">Luxury: Gran Melia</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">Meals & Drinks: at own expense</p>
                </CardContent>
              </Card>

              <Card className="border border-[#ffd6a7] rounded-[10px]">
                <CardContent className="p-4 flex flex-col gap-4">
                  <div className="bg-[#ffedd4] px-2 py-1 inline-block">
                    <h3 className="[font-family:'Inter',sans-serif] font-normal text-base text-neutral-950 tracking-[-0.31px]">
                      Day 2: Arusha to Tarangire National Park
                    </h3>
                  </div>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    Your Grant Expedition Safari guide will collect you from your accommodation after breakfast. This morning, you will drive to Tarangire National Park, your first taste of the wild on your luxury safari. The transit drive is approximately two and a half hours on good tarmac roads. The Park is named after the Tarangire River which runs through it. This 'river of warthogs' is the only source of water for wildlife in the region during the dry season. The Park is well known for its elephant families, which can often be seen congregating by the river. You may also see giraffe, bushbuck, and hartebeest. These animals are closely followed by a range of predators, including lions and leopards. There are more breeding species of birds found in Tarangire than anywhere else on the planet! The huge and ancient Baobab trees can be seen here. Some of them are said to have lived for more than a thousand years.
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    Lunch will be at a picnic site inside the Park. After your game drive, you will transit to your luxury accommodation in Karatu.
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#364153] text-sm tracking-[-0.15px]">Accommodation</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">Luxury: Kitela Lodge</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">Meals & Drink: All meals included, All drinks (Premium wines & liquors might be excluded).</p>
                </CardContent>
              </Card>

              <Card className="border border-[#ffd6a7] rounded-[10px]">
                <CardContent className="p-4 flex flex-col gap-4">
                  <div className="bg-[#ffedd4] px-2 py-1 inline-block">
                    <h3 className="[font-family:'Inter',sans-serif] font-normal text-base text-neutral-950 tracking-[-0.31px]">
                      Day 3: Karatu to Serengeti National park
                    </h3>
                  </div>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    After breakfast, you will drive up into the cooler regions of Ngorongoro Conservation Area. There will be a chance to stop and see the spectacular Ngorongoro Crater. You will then transit through Ngorongoro Conservation Area to the Serengeti, entering at the South of the Park.
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    The Serengeti is truly spectacular. It is famous for its vast open grasslands which allow for excellent sightings of wildlife. Whilst it boasts abundant wildlife, it is perhaps best known for the annual Great Migration. Vast numbers of wildebeest; zebra and antelope move in an annual pattern, constantly seeking fresh grazing. The migration can be found during any given month; you just need to know where to look! Depending on what time of year you come, you may get a chance to witness one of the 'Seven Wonders of the Natural World'.
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    You will have a picnic lunch and will overnight at a Luxury Tented Camp in Central Serengeti.
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#364153] text-sm tracking-[-0.15px]">Accommodation</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">Luxury: Nyota Luxury Camp</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">Meals & Drink: All meals included, All drinks (Premium wines & liquors might be excluded)</p>
                </CardContent>
              </Card>

              <Card className="border border-[#ffd6a7] rounded-[10px]">
                <CardContent className="p-4 flex flex-col gap-4">
                  <div className="bg-[#ffedd4] px-2 py-1 inline-block">
                    <h3 className="[font-family:'Inter',sans-serif] font-normal text-base text-neutral-950 tracking-[-0.31px]">
                      Day 4: Serengeti National park
                    </h3>
                  </div>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    There is something quite magical about lying in bed, listening to the sounds of the birds outside. What a way to start your day! Central Serengeti (Seronera) is the heart of the park, where you will find some of the best game viewing at any time of year. Large populations of hippo, giraffe, antelope, elephant and zebra call this area home throughout the year. Big cats including lion, leopard and cheetah can also be found here. Seronera features a vast range of diverse ecosystems including grasslands that stretch out to the horizon and acacia forests.
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    The banks of the Seronera River are lined with lush palm trees, sausage trees and towering yellow fever acacias. The area around the river is buzzing with different bird species and large flocks of black headed herons, marabou storks and various birds of prey. The Retima Hippo Pool can also be found in Seronera. Today, it is possible to do early morning and late afternoon game drives, returning to the Camp for lunch.
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    Otherwise, a full day's game drive with picnic lunch in the Park.
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#364153] text-sm tracking-[-0.15px]">Accommodation</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">Luxury: Nyota Luxury Camp</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">Meals & Drink: All meals included, All drinks (Premium wines & liquors might be excluded)</p>
                </CardContent>
              </Card>

              <Card className="border border-[#ffd6a7] rounded-[10px]">
                <CardContent className="p-4 flex flex-col gap-4">
                  <div className="bg-[#ffedd4] px-2 py-1 inline-block">
                    <h3 className="[font-family:'Inter',sans-serif] font-normal text-base text-neutral-950 tracking-[-0.31px]">
                      Day 5: Serengeti to Ngorongoro
                    </h3>
                  </div>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    After breakfast, you will wind your way towards Ngorongoro Crater, hopefully enjoying more wonder on the way! Ngorongoro Crater was formed around three million years ago when a volcano (thought to be larger than Kilimanjaro) exploded and collapsed in on itself. It has a diameter of approximately 19km (12 miles) and boasts one of the densest large mammal populations in the whole of the African continent. Over 30,000 animals (including the endangered black Rhino) call this unique place home. After a full afternoon inside the Crater, you will drive to your accommodation in Karatu.
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-bold text-[#364153] text-sm tracking-[-0.15px]">Accommodation</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">Luxury: Kitela Lodge</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">Meals & Drink: All meals included, All drinks (Premium wines & liquors might be excluded)</p>
                </CardContent>
              </Card>

              <Card className="border border-[#ffd6a7] rounded-[10px]">
                <CardContent className="p-4 flex flex-col gap-4">
                  <div className="bg-[#ffedd4] px-2 py-1 inline-block">
                    <h3 className="[font-family:'Inter',sans-serif] font-normal text-base text-neutral-950 tracking-[-0.31px]">
                      Day 6: Lake Manyara National Park
                    </h3>
                  </div>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    This morning, you will drive to Lake Manyara National Park, your final destination on this epic luxury safari! Upon entering the Park, you will immediately be inside a ground water forest which boasts ancient mahogany trees, giant fig trees and the lesser known kapok trees. This part of the park is normally lush and green. You may see baboon and elephant in the park's thick evergreen forest and watch for the tree-climbing lions that have become famous throughout Africa.
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    You will enjoy a picnic lunch inside the Park. After your game drive, you will be dropped off at a place of your choosing e.g. Arusha Town, Kilimanjaro Airport or Arusha Airport. We hope you have enjoyed your adventure with Grant Expedition!
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    No accommodation (End of tour)
                  </p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#364153] text-sm tracking-[-0.15px] leading-5">
                    Meals & Drink: Breakfast & Lunch, Drinks not included
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-2 gap-8">
              <div className="flex flex-col gap-4">
                <h3 className="[font-family:'Inter',sans-serif] font-medium text-neutral-950 text-lg tracking-[-0.44px] leading-[27px]">
                  What's Included
                </h3>
                <div className="flex flex-col gap-2">
                  {[
                    "Accommodation for 5 nights (placeholder)",
                    "All meals during the safari",
                    "Professional safari guide",
                    "Park entrance fees",
                    "4×4 safari vehicle",
                    "Airport transfers"
                  ].map((item, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <div className="w-4 h-4 rounded-full border-2 border-[#00a63e] flex items-center justify-center p-[2px] mt-1">
                        <div className="w-2 h-2 rounded-full bg-[#00a63e]" />
                      </div>
                      <p className="[font-family:'Inter',sans-serif] font-normal text-neutral-950 text-sm tracking-[-0.15px] leading-5">{item}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <h3 className="[font-family:'Inter',sans-serif] font-normal text-neutral-950 text-base tracking-[-0.31px] leading-6">
                  Not Included
                </h3>
                <div className="flex flex-col gap-2">
                  {[
                    "International flights",
                    "Travel insurance",
                    "Personal expenses",
                    "Alcoholic beverages",
                    "Tips and gratuities"
                  ].map((item, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <div className="w-4 h-4 rounded-full border-2 border-[#e7000b] flex items-center justify-center p-[2px] mt-1">
                        <div className="w-2 h-2">
                          <svg viewBox="0 0 8 8" className="w-full h-full">
                            <path d="M1 1 L7 7 M7 1 L1 7" stroke="#e7000b" strokeWidth="1.5" />
                          </svg>
                        </div>
                      </div>
                      <p className="[font-family:'Inter',sans-serif] font-normal text-neutral-950 text-sm tracking-[-0.15px] leading-5">{item}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="w-[389px] flex-shrink-0">
            <Card className="border border-gray-200 rounded-[14px] sticky top-4">
              <CardContent className="p-6 flex flex-col gap-10">
                <h3 className="[font-family:'Inter',sans-serif] font-normal text-neutral-950 text-base tracking-[-0.31px] leading-6">
                  Trip Details
                </h3>

                <div className="flex flex-col gap-3">
                  <div className="flex gap-3">
                    <div className="w-5 h-5 flex-shrink-0 mt-0.5">
                      <svg viewBox="0 0 20 20" className="w-full h-full">
                        <rect x="3" y="4" width="14" height="13" rx="2" stroke="currentColor" fill="none" strokeWidth="1.5"/>
                        <line x1="3" y1="8" x2="17" y2="8" stroke="currentColor" strokeWidth="1.5"/>
                        <line x1="7" y1="2" x2="7" y2="6" stroke="currentColor" strokeWidth="1.5"/>
                        <line x1="13" y1="2" x2="13" y2="6" stroke="currentColor" strokeWidth="1.5"/>
                      </svg>
                    </div>
                    <div className="flex flex-col">
                      <p className="[font-family:'Inter',sans-serif] font-normal text-[#4a5565] text-sm tracking-[-0.15px] leading-5">Duration</p>
                      <p className="[font-family:'Inter',sans-serif] font-normal text-neutral-950 text-base tracking-[-0.31px] leading-6">
                        6 Days / 5 Nights <span className="text-[#6a7282] text-xs">(placeholder)</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-5 h-5 flex-shrink-0 mt-0.5">
                      <svg viewBox="0 0 20 20" className="w-full h-full">
                        <circle cx="10" cy="7" r="3" stroke="currentColor" fill="none" strokeWidth="1.5"/>
                        <path d="M4 18 Q4 13 10 13 Q16 13 16 18" stroke="currentColor" fill="none" strokeWidth="1.5"/>
                      </svg>
                    </div>
                    <div className="flex flex-col">
                      <p className="[font-family:'Inter',sans-serif] font-normal text-[#4a5565] text-sm tracking-[-0.15px] leading-5">Group Size</p>
                      <p className="[font-family:'Inter',sans-serif] font-normal text-neutral-950 text-base tracking-[-0.31px] leading-6">
                        Max 6 People <span className="text-[#6a7282] text-xs">(placeholder)</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-5 h-5 flex-shrink-0 mt-0.5">
                      <svg viewBox="0 0 20 20" className="w-full h-full">
                        <path d="M10 2 L10 10 L14 14" stroke="currentColor" fill="none" strokeWidth="1.5" strokeLinecap="round"/>
                        <circle cx="10" cy="10" r="8" stroke="currentColor" fill="none" strokeWidth="1.5"/>
                      </svg>
                    </div>
                    <div className="flex flex-col">
                      <p className="[font-family:'Inter',sans-serif] font-normal text-[#4a5565] text-sm tracking-[-0.15px] leading-5">Mobility</p>
                      <p className="[font-family:'Inter',sans-serif] font-normal text-neutral-950 text-base tracking-[-0.31px] leading-6">Moderate</p>
                    </div>
                  </div>
                </div>

                <div className="border-t border-[rgba(0,0,0,0.1)] pt-4 flex flex-col gap-2">
                  <p className="[font-family:'Inter',sans-serif] font-normal text-[#4a5565] text-sm tracking-[-0.15px] leading-5">Price per person</p>
                  <p className="[font-family:'Inter',sans-serif] font-normal text-neutral-950 text-2xl tracking-[0.07px] leading-8">
                    $2,499 <span className="text-[#6a7282] text-sm">placeholder USD</span>
                  </p>
                </div>

                <Link href="/booking" className="w-full">
                  <Button className="w-full h-auto px-4 py-2 rounded-lg bg-[#f54900] hover:bg-[#d64000] text-white">
                    <span className="[font-family:'Inter',sans-serif] font-medium text-sm tracking-[-0.15px] leading-5">Book This Trip</span>
                  </Button>
                </Link>

                <Link href="/contact" className="w-full">
                  <Button variant="outline" className="w-full h-auto px-4 py-2 rounded-lg border border-[#d1d5dc] bg-white hover:bg-gray-50">
                    <span className="[font-family:'Inter',sans-serif] font-medium text-neutral-950 text-sm tracking-[-0.15px] leading-5">Contact Us</span>
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <FooterSection />
    </div>
  );
};
