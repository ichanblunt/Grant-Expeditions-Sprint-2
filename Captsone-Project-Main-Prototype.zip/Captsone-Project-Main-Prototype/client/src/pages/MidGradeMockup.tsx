import React from "react";
import { ActivitiesSection } from "./sections/ActivitiesSection";
import { ContentWrapperSection } from "./sections/ContentWrapperSection";
import { FooterSection } from "./sections/FooterSection";
import { HeaderSection } from "./sections/HeaderSection";
import { TourPackagesSection } from "./sections/TourPackagesSection";
import { TourPackagesWrapperSection } from "./sections/TourPackagesWrapperSection";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import giraffeImage from "@assets/giraffe1_1762387397780.jpg";
import lionImage from "@assets/lion1_1762387397781.jpg";
import cheetahImage from "@assets/cheetah1_1762387397782.jpg";

export const MidGradeMockup = (): JSX.Element => {
  const plugin = React.useRef(
    Autoplay({ delay: 4000, stopOnInteraction: true })
  );

  const carouselImages = [
    { src: giraffeImage, alt: "Giraffe on safari in Tanzania" },
    { src: lionImage, alt: "Lions in the Serengeti" },
    { src: cheetahImage, alt: "Leopard in Tanzania" },
  ];

  return (
    <div className="bg-white w-full relative flex flex-col">
      <HeaderSection />

      <section className="w-full relative flex flex-col items-center px-[71.5px] py-0 bg-[linear-gradient(135deg,rgba(255,214,167,1)_0%,rgba(255,184,106,1)_50%,rgba(187,77,0,1)_100%)]">
        <div className="relative w-full max-w-[1280px] pt-20 pb-8">
          <div className="w-full flex justify-center mb-[55px]">
            <h1 className="[font-family:'Merriweather',Helvetica] font-bold text-black text-5xl text-center tracking-[0] leading-[48px] whitespace-nowrap">
              Safaris, Trekking, Beaches, and More!
            </h1>
          </div>

          <div className="w-full flex justify-center">
            <Carousel
              plugins={[plugin.current]}
              className="w-full max-w-[972px]"
              onMouseEnter={plugin.current.stop}
              onMouseLeave={plugin.current.reset}
            >
              <CarouselContent>
                {carouselImages.map((image, index) => (
                  <CarouselItem key={index}>
                    <div className="w-full h-[500px] overflow-hidden rounded-lg shadow-lg">
                      <img
                        className="w-full h-full object-cover"
                        alt={image.alt}
                        src={image.src}
                      />
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="left-4" />
              <CarouselNext className="right-4" />
            </Carousel>
          </div>
        </div>
      </section>

      <ActivitiesSection />

      <section className="w-full relative flex flex-col items-center pt-6 pb-px px-0 border-b [border-bottom-style:solid] border-[#0000001a]">
        <div className="relative w-full max-w-[1280px]">
          <h2 className="[font-family:'Merriweather',Helvetica] font-bold text-black text-4xl text-center tracking-[0] leading-10 whitespace-nowrap">
            Explore the Wonders of Africa!
          </h2>
        </div>
      </section>

      <div className="w-full relative flex">
        <TourPackagesWrapperSection />
        <TourPackagesSection />
        <ContentWrapperSection />
      </div>

      <FooterSection />
    </div>
  );
};
